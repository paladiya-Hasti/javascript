
let  Name="white"
let n=Name.length

for(let i=n-1; i>=0; i--)
{
    if(i%2!=0 || i==0)
    {
        console.log(Name[i])
    }
}