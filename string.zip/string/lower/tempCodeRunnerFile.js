

function upperstr(){
    let str=document.getElementById("upper").value

    let console.log(str)
}