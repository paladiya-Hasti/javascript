

function upperstr(){
    let str=document.getElementById("upper").value

    console.log=(str)
}