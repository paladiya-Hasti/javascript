let  Name="redandwhite"
let n=Name.length

for(let i=0; i<n; i++)
{
    console.log(Name[i])
}