let str="red"
let n=str.length

for(let i=0; i<n; i++){
    if(str[i]=="a"|| str[i]=="e" ||str[i]=="i"||str[i]=="0"||str[i]=='u')
    {
        console.log(true)
    }
}