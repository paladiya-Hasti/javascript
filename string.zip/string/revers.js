let  Name="white"
let n=Name.length

for(let i=n-1; i>=0; i--)
{
    console.log(Name[i])
}