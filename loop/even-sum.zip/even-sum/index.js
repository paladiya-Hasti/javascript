let sum = 0
let num=6

for (let i = 2; i <= num; i += 2) {
    sum += i;
}
console.log(sum);
