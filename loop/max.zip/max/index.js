
for(let i=14; i<=18; i++){
    console.log(i);
}

max=10
min=6
for(let i=6; i<=10; i++){
    console.log(i);
}