let a=10
let b=20
let c=2

let div= a + b / c

console.log("div")

document.getElementById("div").innerHTML=`div of ${div}`