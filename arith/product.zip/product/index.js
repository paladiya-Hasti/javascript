let pen=2
let toy=5
let bag=5
let bottal=2
let key=8
let ans=(pen * toy * bag * bottal * key)

console.log("ans")

document.getElementById("product").innerHTML=`product values of ${ans}`