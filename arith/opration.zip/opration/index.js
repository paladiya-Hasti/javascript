// let a=5
// let b=8
// let c=12
let d=4
let e=3
let f=7
let g=10

let ans=( d *e + f - g)

console.log("ans")

document.getElementById("operation").innerHTML=`operation number of ${ans}`