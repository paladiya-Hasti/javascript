let a=2

let sum=a*a*a

console.log(sum)
document.getElementById("cub").innerHTML=`cub of ${a} ${sum}`