let a=1
let b=2
let c=3

let sum =a*a + b*b + c*c

console.log(sum)
document.getElementById("square").innerHTML=`square of ${sum}`