let name='hasti'
let age=23
console.log("name")
console.log("age")

document.getElementById("name").innerHTML=`name =${name} <br> age = ${age}`