let a=4
let b=4
let c=4
let d=4
let e=4
let sum=a+b+c+d+e

console.log("sum")

document.getElementById("five").innerHTML=`number of${sum}`