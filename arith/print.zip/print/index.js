let a='red and white'

let ans=a

console.log("ans")

document.getElementById("red").innerHTML=`A transformation in Education <br> ${a}`