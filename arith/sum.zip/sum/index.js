let a=5
let b=6
let c=8
let d=4

let sum= a + b - c + d

console.log("sum")

document.getElementById("sum").innerHTML=` sum of ${sum}`