let a=10
let b=20

let ans=a
let as=b
document.getElementById("var").innerHTM=`${ans}<br>${as}`