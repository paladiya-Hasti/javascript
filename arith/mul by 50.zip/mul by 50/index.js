let one=2

let ans= one*50

console.log("ans")

document.getElementById("mul").innerHTML=`multiply of ${ans}`