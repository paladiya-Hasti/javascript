let a=7
let squ = a*a
console.log("squ")
document.getElementById("squ").innerHTML=`square it ${squ}`