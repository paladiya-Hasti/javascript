class employe{
    constructor(id,salary,cat,address,name){
        this.id=id;
        this.salary=salary;
        this.cat=cat;
        this.address=address
        this.name=name;
    }
    id(){
        console.log(`${this.name} your id??`);
    }
    salary(){
        console.log(`${this.name} your salary??`);
    }
    cat(){
        console.log(`${this.name} your phone??`);
    }   
    address(){
        console.log(`${this.name} your bhukh??`);
    }

}
class manger extends employe{
    constructor(leave){
        manger(id,salary,cat,address,name)
        this.leave=leave;
    }
    leave(){
        console.log(`${this.name} chhutiii.....`);
    }

} 
let vraj=new employe(410,10000000,3,"bhaji",1,"hasti");
vraj.id();

let hasti=new  manger(7)
hasti.salary();