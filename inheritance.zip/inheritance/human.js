class human{
    constructor (hath,pag,name,fly){
        this.hath=hath;
        this.pag=pag;
        this.name=name;
        this.fly=fly;
    }
    cha(){
        console.log(`${this.name}dod skata hai`);
    }
    flying(){
        console.log(`${this.name}i am fly`);
    }
}
class superhuman extends human {
    constructor (hath,pag,name,fly,dimag){
    super (hath,pag,name,fly)
        this. dimag=dimag;    
    }
    usekarskatahai(){
        console.log(`${this.name} use kar sakta hai.....`);
    }
}


// let hasti=new human(2,2,"vraj","fly")
let ayushi=new superhuman(2,2,"vraj","fly",3)

// hasti.flying();
ayushi.usekarskatahai();