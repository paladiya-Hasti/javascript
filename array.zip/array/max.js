function findMax() {
	var Arr = [2,3,4,5,6,9,10,3];

	var maxValue = Math.max(...Arr);
	
	console.log("Maximum Element is:" + maxValue);
}

findMax()
