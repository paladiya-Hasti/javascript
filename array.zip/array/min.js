
function findMin() {
	var Arr = [2,3,4,5,6,9,10,3];

	var minValue = Math.min(...Arr);	
	console.log("Minimum element is:" + minValue);
}

findMin()
