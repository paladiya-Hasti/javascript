// add

let a=50
let b=50
let c=10

let sum=a+b+c
let sub=a-b-c
let mul=a*b*c
let mud=a/b
let div=a/b

document.getElementById("add").innerHTML=`sum of three number ${a} ${b} ${c} = ${sum}`
document.getElementById("sub").innerHTML=`sum of three number ${a} ${b} ${c} = ${sub}`
document.getElementById("mul").innerHTML=`sum of three number ${a} ${b} ${c} = ${mul}`
document.getElementById("mud").innerHTML=`sum of two number ${a} ${b} = ${mud}`
document.getElementById("div").innerHTML=`sum of two number ${a} ${b} = ${div}`

