let a=43

if(a%2==0)
{
    console.log("it's  an even number")
    document.getElementById("even").innerHTML=`even`
}
else{
    console.log("odd")
}