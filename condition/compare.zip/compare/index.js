let num1=4
let num2=8

let num3=5

if(num1 > num2)
{
    console.log("true")
    document.getElementById("compare").innerHTML=`true`
}
// else if(num1+1){
//     console.log("true")
//     document.getElementById("compare").innerHTML=`true` 
// }
else{
    console.log("false")
    document.getElementById("compare").innerHTML=`false` 
}
