let a=6
let b=19
let c=100

if(a>b){
    console.log("a os largest number")
    document.getElementById("three").innerHTML=`a is largest number`
}
else if(b>c){
    console.log(" b is largest number")
    document.getElementById("three").innerHTML=`b is largest number`
}
else{
    console.log("c is best")
    document.getElementById("three").innerHTML=`c is best number`
}