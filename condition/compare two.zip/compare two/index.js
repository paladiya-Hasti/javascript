let a=40
let b=40

if(a < b)
{
    console.log("true")
    document.getElementById("two").innerHTML=`greater`
}
else if(a == b){
    console.log("false")
    document.getElementById("two").innerHTML=`false`
}
else if(a > b){
    console.log("false")
    document.getElementById("two").innerHTML=`smaller`
}
else{
    console.log("fgsg")
    document.getElementById("two").innerHTML=`true`
}