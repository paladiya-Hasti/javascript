let a=6

if(a%3==0){
    console.log("possive")
    document.getElementById("wood").innerHTML=`possible`
}
else{
    console.log("no")
    document.getElementById("wood").innerHTML=`not possible`
}