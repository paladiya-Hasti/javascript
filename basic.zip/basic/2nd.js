let a=2
let b=3
let c=6
let d=2
let e=5

let sum=(a+b+d)-(c+e)

console.log(sum)