
function nameage(){
    var name=document.getElementById("name").value
    let age=document.getElementById("age").value
    console.log(name)
    console.log(age)
}