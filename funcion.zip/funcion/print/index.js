function print(){
    let a= document.getElementById("num1").value
    console.log(a)

    a=document.getElementById("num2").value
    console.log(a)
}