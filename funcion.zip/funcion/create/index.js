function sum(){
    let a=document.getElementById("num1").value
    let b=document.getElementById("num2").value
    let c=document.getElementById("num3").value
    console.log(Number(a)+Number(b)+ Number(c))
}