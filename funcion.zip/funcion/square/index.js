function squ(){
    let a= document.getElementById("num2").value
    console.log(a*a)
}