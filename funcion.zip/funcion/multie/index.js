
function mul(){
    let a=document.getElementById("num1").value
    console.log(a*50)
}