
function divisible()
{
    let a=document.getElementById("num1").Value

    if(a%3==0){
        console.log("yes")
    }
    else{
        console.log("no")
    }
}