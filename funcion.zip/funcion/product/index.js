
function multiplication(){
    let one=document.getElementById("num1").value
    let two=document.getElementById("num2").value
    let three=document.getElementById("num3").value
    let four=document.getElementById("num4").value
    let five=document.getElementById("num5").value
    console.log(one*two*three*four*five)
}
