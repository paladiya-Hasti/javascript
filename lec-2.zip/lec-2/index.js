alert("welcome to resume");
document.getElementById("name").innerHTML="vaishali paladiya";
document.getElementById("pic").src="https://avatars.mds.yandex.net/i?id=1491e30c366b9d23924e059907c9639fcecc456c-10837749-images-thumbs&n=13";
document.getElementById("no").innerHTML="contact no : 7984400855";
document.getElementById("email").innerHTML="vaishalipaladiya1996@gmail.com";